# Employee Data Assignment

# Array of employee last names and salaries
employee_names = ["Adams", "Baker", "Clark", "Davis", "Evans", "Frank", "Green", "Harris", "Iverson", "Jones"]
salaries = [55000, 62000, 48000, 75000, 51000, 68000, 72000, 59000, 64000, 57000]

# Function to display employee names and salaries
def display_employees(names, salaries):
    for i in range(len(names)):
        print(f"{names[i]}: ${salaries[i]:,.2f}")

# Function to display names in reverse order
def display_names_reverse(names):
    for name in reversed(names):
        print(name)

# Function to find the employee with the highest salary
def find_highest_salary(names, salaries):
    highest_index = salaries.index(max(salaries))
    print(f"Highest Salary: {names[highest_index]} with ${salaries[highest_index]:,.2f}")

# Function to sum and display total salaries
def display_total_salaries(salaries):
    total = sum(salaries)
    print(f"Total of all salaries: ${total:,.2f}")

# Function to search for an employee by last name and display their salary
def search_employee(names, salaries, name):
    if name in names:
        index = names.index(name)
        print(f"{name}: ${salaries[index]:,.2f}")
    else:
        print(f"Employee {name} not found.")

# Display employee names and salaries
print("Employee Names and Salaries:")
display_employees(employee_names, salaries)

# Display names in reverse order
print("\nEmployee Names in Reverse Order:")
display_names_reverse(employee_names)

# Display the employee with the highest salary
print("\nEmployee with the Highest Salary:")
find_highest_salary(employee_names, salaries)

# Display the total of all salaries
print("\nTotal of All Salaries:")
display_total_salaries(salaries)

# Example of searching for an employee
print("\nSearch for an Employee:")
search_employee(employee_names, salaries, "Green")
