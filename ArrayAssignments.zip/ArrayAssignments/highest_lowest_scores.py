# Assignment 3

# Array of last names
last_names = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Martinez", "Hernandez"]

# Parallel array of exam scores
exam_scores = [85, 92, 78, 88, 91, 73, 89, 95, 84, 76]

# Function to find and display the last name with the highest and lowest scores
def find_highest_lowest(names, scores):
    highest_index = scores.index(max(scores))
    lowest_index = scores.index(min(scores))

    print(f"Highest Score: {names[highest_index]} with {scores[highest_index]}")
    print(f"Lowest Score: {names[lowest_index]} with {scores[lowest_index]}")

# Display the highest and lowest scores
find_highest_lowest(last_names, exam_scores)
