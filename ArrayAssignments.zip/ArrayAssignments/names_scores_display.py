# names_scores_display.py

# Array of last names
last_names = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Martinez", "Hernandez"]

# Parallel array of exam scores
exam_scores = [85, 92, 78, 88, 91, 73, 89, 95, 84, 76]

# Function to display names and scores
def display_names_and_scores(names, scores):
    for i in range(len(names)):
        print(f"{names[i]}: {scores[i]}")

# Display the names and scores
print("Names and Exam Scores:")
display_names_and_scores(last_names, exam_scores)
