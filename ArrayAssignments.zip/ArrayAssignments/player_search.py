# Assignment 4

# Array of player names and batting averages
player_names = ["Anderson", "Bryant", "Cabrera", "Davis", "Escobar", "Frazier", "Gonzalez", "Harper", "Ichiro", "Jones"]
batting_averages = [0.267, 0.280, 0.301, 0.275, 0.250, 0.290, 0.320, 0.310, 0.285, 0.260]

# Function to display player names and batting averages
def display_players(players, averages):
    for i in range(len(players)):
        print(f"{players[i]}: {averages[i]:.3f}")

# Function to search for a player by last name and display their batting average
def search_player(players, averages, name):
    if name in players:
        index = players.index(name)
        print(f"{name}: {averages[index]:.3f}")
    else:
        print(f"Player {name} not found.")

# Display the player names and batting averages
print("Player Names and Batting Averages:")
display_players(player_names, batting_averages)

# Example of searching for a player
print("\nSearch for a player:")
search_player(player_names, batting_averages, "Gonzalez")
