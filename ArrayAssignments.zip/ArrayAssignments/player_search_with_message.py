# Assignment 5

# Define player names and batting averages (using the same data from Assignment 4)
player_names = ["Anderson", "Bryant", "Cabrera", "Davis", "Escobar", "Frazier", "Gonzalez", "Harper", "Ichiro", "Jones"]
batting_averages = [0.267, 0.280, 0.301, 0.275, 0.250, 0.290, 0.320, 0.310, 0.285, 0.260]

# Function to search for a player by last name and display their batting average with a not found message
def search_player_with_message(players, averages, name):
    if name in players:
        index = players.index(name)
        print(f"{name}: {averages[index]:.3f}")
    else:
        print(f"Player {name} not found.")

# Example of searching for a player with a message
print("\nSearch for a player with a message:")
search_player_with_message(player_names, batting_averages, "Doe")

